import 'package:flutter/material.dart';

import '../constants/app_colors.dart';
import '../data/attractions_data.dart';
import '../models/attraction.dart';
import '../widgets/attraction_card.dart';

class ExploreScreen extends StatelessWidget {
  final List<Attraction> favorites;
  final Function(Attraction) onFavoriteToggle;

  const ExploreScreen({
    super.key,
    required this.favorites,
    required this.onFavoriteToggle,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          color: AppColors.primary,
          padding: const EdgeInsets.all(15),
          child: TextField(
            decoration: InputDecoration(
              hintText: "Search attractions",
              prefixIcon: const Icon(Icons.search),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(30),
                borderSide: BorderSide.none,
              ),
            ),
          ),
        ),
        Expanded(
          child: ListView.builder(
            itemCount: attractions.length,
            itemBuilder: (context, index) {
              final attraction = attractions[index];
              return AttractionCard(
                attraction: attraction,
                isFavorite: favorites.contains(attraction),
                onFavoritePressed: () => onFavoriteToggle(attraction),
              );
            },
          ),
        ),
      ],
    );
  }
}
