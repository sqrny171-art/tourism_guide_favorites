import 'package:flutter/material.dart';

import '../constants/app_colors.dart';
import '../models/attraction.dart';
import 'explore_screen.dart';
import 'favoriate_screen.dart';

class HomeScreen extends StatefulWidget {
  HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int screen_num = 0;

  // القائمة الأساسية للأماكن التي اختارها المستخدم كمفضلة
  final List<Attraction> favorites = [];

  void toggleFavorite(Attraction attraction) {
    setState(() {
      if (favorites.contains(attraction)) {
        favorites.remove(attraction);
      } else {
        favorites.add(attraction);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      ExploreScreen(
        favorites: favorites,
        onFavoriteToggle: toggleFavorite,
      ),
      FavoriateScreen(
        favorites: favorites,
        onFavoriteToggle: toggleFavorite,
      ),
    ];

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        title: const Text(
          "Tourism Egypt",
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: screens[screen_num],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: screen_num,
        onTap: (index) {
          setState(() {
            screen_num = index;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Explore",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.favorite),
            label: "Favorites",
          ),
        ],
      ),
    );
  }
}
