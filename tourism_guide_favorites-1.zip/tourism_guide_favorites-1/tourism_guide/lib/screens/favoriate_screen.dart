import 'package:flutter/material.dart';

import '../models/attraction.dart';
import '../widgets/attraction_card.dart';

class FavoriateScreen extends StatelessWidget {
  final List<Attraction> favorites;
  final Function(Attraction) onFavoriteToggle;

  const FavoriateScreen({
    super.key,
    required this.favorites,
    required this.onFavoriteToggle,
  });

  @override
  Widget build(BuildContext context) {
    if (favorites.isEmpty) {
      return const Center(
        child: Text(
          'No favorite places yet',
          style: TextStyle(fontSize: 18, color: Colors.grey),
        ),
      );
    }

    return ListView.builder(
      itemCount: favorites.length,
      itemBuilder: (context, index) {
        final attraction = favorites[index];
        return AttractionCard(
          attraction: attraction,
          isFavorite: true,
          onFavoritePressed: () => onFavoriteToggle(attraction),
        );
      },
    );
  }
}
